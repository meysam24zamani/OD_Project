package com.company;

import java.util.ArrayList;
import java.util.Random;
//class that fills the information of Conference and journals.
public class ConferenceJournals {

    String title;
    String type;
    String Location;
    ArrayList<String> LocationList;
//empty constructor.
    ConferenceJournals(){

       title="";
       type="";
       LocationList =  new ArrayList<>();



    }
//constructor with values.
    ConferenceJournals (String ti,String ty,String l){

        title=ti;
        type=ty;
        LocationList =  new ArrayList<>();
        Location=l;



    }
//Function that fills the information about the conference and journals.
    ArrayList <ConferenceJournals>  getConferenceJournals(){

        ArrayList<ConferenceJournals> aux = new ArrayList<ConferenceJournals>();
        LocationList.add("Argetina");
        LocationList.add("Australia");
        LocationList.add("Brazil");
        LocationList.add("Canada");
        LocationList.add("China");
        LocationList.add("Ecuador");
        LocationList.add("Germany");
        LocationList.add("Italy");
        LocationList.add("Israel");
        LocationList.add("Luxembourg");
        LocationList.add("Mexico");
        LocationList.add("Netherlands");
        LocationList.add("Russia");
        LocationList.add("Sweden");
        LocationList.add("Switzerland");
        LocationList.add("United States of America");
        Random random = new Random();
        aux.add(new ConferenceJournals("IEEE Conference on Computer Vision and Pattern Recognition","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Science","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Annual Conference on Neural Information Processing Systems","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Nucleic Acids Research","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("International Conference on Machine Learning","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("European Conference on Computer Vision","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("International Conference on Computer Vision","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Transactions on Pattern Analysis and Machine Intelligence","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Transactions on Wireless Communications","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Transactions on Image Processing","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("NeuroImage","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Information Sciences","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Transactions on Cybernetics","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Transactions on Neural Networks and Learning Systems","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Annual Meeting of the Association for Computational Linguistics","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Transactions on Geoscience and Remote Sensing","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("AAAI Conference on Artificial Intelligence","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Journal of Selected Areas in Communications","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("IEEE Transactions on Information Theory","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Conference on Empirical Methods in Natural Language Processing","Conference",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("ACM Computing Surveys","Journal",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("ACM Transactions on Computer Systems","Journal",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("ACM Transactions on Computer-Human Interaction","Journal",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("ACM Transactions on Database Systems","Journal",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("ACM Transactions on Graphics","Journal",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Algorithmica","Journal",LocationList.get(random.nextInt(14))));
        aux.add(new ConferenceJournals("Annual Review of Information Science and Technology","Journal",LocationList.get(random.nextInt(14))));
        return aux;
    }

}
