package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.IntStream;

//class that fills the information about the author.
public class Author {

    String Name;
    Integer Age;
    String Nationality;
    String email;
    ArrayList<String> NList;
//empty constructor.
    Author() {
        Name="";
        Age=0;
        Nationality="";
        email="";
        NList = new ArrayList<String>();
        //add nationalities
        NList.add("British");
        NList.add("Scottish");
        NList.add("Irish");
        NList.add("Finnish");
        NList.add("Norwegian");
        NList.add("Swedish");
        NList.add("Belgian");
        NList.add("French");
        NList.add("German");
        NList.add("Italian");
        NList.add("American");
        NList.add("Canadian");
        NList.add("Mexican");
        NList.add("Greece");
        NList.add("Spain");

    }

//constructor with values.
    Author(String n, Integer a, String na, String e) {

        Name = n;
        Age = a;
        Nationality = na;
        email=e;

    }
/*function that returns an arraylist of authors with the information extracted from the authors.csv and some information
    generated randomly*/
    ArrayList<Author> getallauthors() throws IOException {

        ArrayList<Author> aux = new ArrayList<Author>();
        String row1;
        File csvFile = new File("C:/Users/jmore/Desktop/sourcesOD/authors.csv");
        int[] range = IntStream.rangeClosed(18, 80).toArray();
        Random random = new Random();
        int number=0;
        if (csvFile.isFile()) {

            BufferedReader csvReader = new BufferedReader(new FileReader("C:/Users/jmore/Desktop/sourcesOD/authors.csv"));
            while ((row1 = csvReader.readLine()) != null && number<50000 ) {
                String[] data = row1.split(";");
                int agelocal = range[random.nextInt(60)];
                String n= NList.get(random.nextInt(14));
                String aname= data[1];
                aname = aname.replaceAll("^\"|\"$", "");
                String emailauthor= aname.substring(0,2);
                emailauthor=emailauthor+Integer.toString(random.nextInt(20))+"@gmail.com";
                Author auxauthor = new Author(aname,agelocal,n,emailauthor);
                aux.add(auxauthor);
                number=number+1;
            }

        }
        return aux;
    }
}
