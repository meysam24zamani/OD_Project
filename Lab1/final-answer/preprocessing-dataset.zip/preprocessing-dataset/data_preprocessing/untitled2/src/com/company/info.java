package com.company;

//this class is the superclass that is needed in terms of getting all the info needed to construct the csv file
public class info {
    String AuthorName;
    Integer Age;
    String Nationality;
    String email;
    String Papertitle;
    String CorJ;
    Integer Year;
    String CorJTitle;
    String ConferenceLocation;
    String ISBN;
    int Npages;
    int Volume;
    int edition;
    String DOI;
    String keyword1;
    String keyword2;
    String keyword3;
    String keyword4;



//empty constructor
    info(){

        AuthorName="";
        Age=0;
        Nationality="";
        email="";
        Papertitle="";
        CorJ="";
        Year=0;
        CorJTitle="";
        ConferenceLocation="";
        ISBN="";
        Npages=0;
        Volume=0;
        edition=0;
        DOI="";
        keyword1="";
        keyword2="";
        keyword3="";
        keyword4="";

    }
//constructor with values
    info(String a,Integer ag,String n,String e,String p, String cor, Integer y, String Corti,String ConfLo,String I,String D,Integer N,Integer V,Integer E,String k1,String k2,String k3,String k4){

        AuthorName=a;
        Age=ag;
        Nationality=n;
        email=e;
        Papertitle=p;
        CorJ=cor;
        Year=y;
        CorJTitle=Corti;
        ConferenceLocation=ConfLo;
        ISBN=I;
        DOI=D;
        Npages=N;
        Volume=V;
        edition=E;
        keyword1=k1;
        keyword2=k2;
        keyword3=k3;
        keyword4=k4;

    }

    info(String n,Integer a, String na){

        AuthorName=n;
        Age=a;
        Nationality=na;

    }
}
