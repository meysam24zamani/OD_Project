package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

public class Main {

    /*
    Program to generate the dataset that are project needs. In the main function, we get all the info that we need
    from the classes author articles and conferencejournals to fill a csv file that will be the final dataset
    with a distiction if it's a conference or a journal.
     */
    public static void main(String[] args) throws IOException {
        String row1,row2,row3;
        int numberauthor=0;
        //getting the information from the others classes.
        Article articulos = new Article();
        ConferenceJournals conferencias= new ConferenceJournals();
        ArrayList <info> information = new ArrayList<info>();
        ArrayList<Article> articleslist = articulos.getAllArticles();
        ArrayList<ConferenceJournals> listaconferencias = conferencias.getConferenceJournals();
        Author autores = new Author();
        ArrayList<Author> authorslist = autores.getallauthors();
        //filling the keywords.
        List<String> k = Arrays.asList("artificial intelligence", "Machine Learning", "Deep Learning"
        ,"Robotics","Reinforcement Learning","Natural Language Processing","Computer Vision","Recommender Systems","Internet of Things",
                "Service and cloud computing","pervasive computing and collaboration","Energy lab","Scalable internet services",
                "Technology-enhanced learning","Delay-tolerant networking","database systems","Declarative languages and runtime systems","Scalable data analysis and query processing","Consistency",
                "concurrency","coordination and reliability","Data storage and physical design","Metadata management","Data cleaning","data transformation","Secure data processing","Security","Secure Passwords",
        "Malware","Privacy","Data Breaches","Safe Computing","Online Scams","Mobile Protection","affective computing","using data to design user interfaces","human-centred design in intelligent environments",
                "digital technology for older people","digital health","vision and graphics","Computational Video","Image-based Rendering and Animation","3D Modelling of Humans","3D Scene Analysis",
                "Machine Learning for Computer Vision","Biomedical Image Analysis","Augmented Reality","Elementary and special functions","Numerical linear algebra","Interpolation and approximation","Finding roots of nonlinear equations",
                "Optimization","Numerical quadrature","type theory","automated theorem proving","language semantics","computer security","networking","distributed programming","language implementation","program analysis","domain-specific languages","Automotive software",
        "Avionics software","Electronic warfare engineering","Heating Ventilation","Medical device software","Telephony","Telemetry","computational complexity","data structures",
                "parallel and distributed computation","probabilistic computation","quantum computation","automata theory","cryptography","machine learning","computational biology","computational economics","algebra",
                "sequence alignment","gene finding","genome assembly","drug design","drug discovery","protein structure alignment","protein structure prediction","cell division/mitosis");
        ArrayList<String> Keywords = new ArrayList<>(k);
        int[] range3 = IntStream.rangeClosed(1980, 2020).toArray();
        int counter=0;
        //in terms to get more or less 1000 entrys we set the counter with 240.
        while(counter<240){
            //this if rejects authors with name that got strange values.
            if(authorslist.get(counter).Name.matches("^[ A-Za-z]+$")) {
                Random random = new Random();
                int value1 = random.nextInt(26);
                //here comes some statements to check if the year it's a real year, and if not fill it with a real year.
                //then it adds the information to the information class which has all the info of the excel.
                if ((Integer.toString(articleslist.get(counter).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter).year)).length() == 4) {
                    info info1 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter).ArticleName, listaconferencias.get(value1).type, articleslist.get(counter).year, listaconferencias.get(value1).title, listaconferencias.get(value1).Location, articleslist.get(value1).ISBN, articleslist.get(value1).DOI, articleslist.get(value1).Volume, articleslist.get(value1).Npages, articleslist.get(value1).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info1);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info1 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter).ArticleName, listaconferencias.get(value1).type, t, listaconferencias.get(value1).title, listaconferencias.get(value1).Location, articleslist.get(value1).ISBN, articleslist.get(value1).DOI, articleslist.get(value1).Volume, articleslist.get(value1).Npages, articleslist.get(value1).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info1);

                }
                Random random1 = new Random();
                int value2 = random1.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+1).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+1).year)).length() == 4) {
                    info info2 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 1).ArticleName, listaconferencias.get(value2).type, articleslist.get(counter + 1).year, listaconferencias.get(value2).title, listaconferencias.get(value2).Location, articleslist.get(value2).ISBN, articleslist.get(value2).DOI, articleslist.get(value2).Volume, articleslist.get(value2).Npages, articleslist.get(value2).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info2);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info2 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 1).ArticleName, listaconferencias.get(value2).type, t, listaconferencias.get(value2).title, listaconferencias.get(value2).Location, articleslist.get(value2).ISBN, articleslist.get(value2).DOI, articleslist.get(value2).Volume, articleslist.get(value2).Npages, articleslist.get(value2).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info2);

                }
                Random random2 = new Random();
                int value3 = random2.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+2).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+2).year)).length() == 4) {
                    info info3 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 2).ArticleName, listaconferencias.get(value3).type, articleslist.get(counter + 2).year, listaconferencias.get(value3).title, listaconferencias.get(value3).Location, articleslist.get(value3).ISBN, articleslist.get(value3).DOI, articleslist.get(value3).Volume, articleslist.get(value3).Npages, articleslist.get(value3).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info3);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info3 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 2).ArticleName, listaconferencias.get(value3).type, t, listaconferencias.get(value3).title, listaconferencias.get(value3).Location, articleslist.get(value3).ISBN, articleslist.get(value3).DOI, articleslist.get(value3).Volume, articleslist.get(value3).Npages, articleslist.get(value3).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info3);

                }
                Random random3 = new Random();
                int value4 = random3.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+3).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+3).year)).length() == 4) {
                    info info4 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 3).ArticleName, listaconferencias.get(value4).type, articleslist.get(counter + 3).year, listaconferencias.get(value4).title, listaconferencias.get(value4).Location, articleslist.get(value4).ISBN, articleslist.get(value4).DOI, articleslist.get(value4).Volume, articleslist.get(value4).Npages, articleslist.get(value4).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info4);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info4 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 3).ArticleName, listaconferencias.get(value4).type,t, listaconferencias.get(value4).title, listaconferencias.get(value4).Location, articleslist.get(value4).ISBN, articleslist.get(value4).DOI, articleslist.get(value4).Volume, articleslist.get(value4).Npages, articleslist.get(value4).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info4);

                }
                Random random4 = new Random();
                int value5 = random4.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+4).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+4).year)).length() == 4) {
                    info info5 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 4).ArticleName, listaconferencias.get(value5).type, articleslist.get(counter + 4).year, listaconferencias.get(value5).title, listaconferencias.get(value5).Location, articleslist.get(value5).ISBN, articleslist.get(value5).DOI, articleslist.get(value5).Volume, articleslist.get(value5).Npages, articleslist.get(value5).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info5);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info5 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 4).ArticleName, listaconferencias.get(value5).type, t, listaconferencias.get(value5).title, listaconferencias.get(value5).Location, articleslist.get(value5).ISBN, articleslist.get(value5).DOI, articleslist.get(value5).Volume, articleslist.get(value5).Npages, articleslist.get(value5).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info5);

                }
                int value6 = random4.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+5).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+5).year)).length() == 4) {
                    info info6 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 5).ArticleName, listaconferencias.get(value6).type, articleslist.get(counter + 5).year, listaconferencias.get(value6).title, listaconferencias.get(value6).Location, articleslist.get(value6).ISBN, articleslist.get(value6).DOI, articleslist.get(value6).Volume, articleslist.get(value6).Npages, articleslist.get(value6).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info6);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info6 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 5).ArticleName, listaconferencias.get(value6).type,t, listaconferencias.get(value6).title, listaconferencias.get(value6).Location, articleslist.get(value6).ISBN, articleslist.get(value6).DOI, articleslist.get(value6).Volume, articleslist.get(value6).Npages, articleslist.get(value6).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info6);

                }
                int value7 = random4.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+6).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+6).year)).length() == 4) {
                    info info7 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 6).ArticleName, listaconferencias.get(value7).type, articleslist.get(counter + 6).year, listaconferencias.get(value7).title, listaconferencias.get(value7).Location, articleslist.get(value7).ISBN, articleslist.get(value7).DOI, articleslist.get(value7).Volume, articleslist.get(value7).Npages, articleslist.get(value7).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info7);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info7 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 6).ArticleName, listaconferencias.get(value7).type, t, listaconferencias.get(value7).title, listaconferencias.get(value7).Location, articleslist.get(value7).ISBN, articleslist.get(value7).DOI, articleslist.get(value7).Volume, articleslist.get(value7).Npages, articleslist.get(value7).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));

                    information.add(info7);

                }
                int value8 = random4.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+7).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+7).year)).length() == 4) {
                    info info8 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 7).ArticleName, listaconferencias.get(value8).type, articleslist.get(counter + 7).year, listaconferencias.get(value8).title, listaconferencias.get(value8).Location, articleslist.get(value8).ISBN, articleslist.get(value8).DOI, articleslist.get(value8).Volume, articleslist.get(value8).Npages, articleslist.get(value8).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info8);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info8 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 7).ArticleName, listaconferencias.get(value8).type, t, listaconferencias.get(value8).title, listaconferencias.get(value8).Location, articleslist.get(value8).ISBN, articleslist.get(value8).DOI, articleslist.get(value8).Volume, articleslist.get(value8).Npages, articleslist.get(value8).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));

                    information.add(info8);

                }
                int value9 = random4.nextInt(26);
                if ((Integer.toString(articleslist.get(counter+8).year)).matches("[0-9]+") && (Integer.toString(articleslist.get(counter+8).year)).length() == 4) {
                    info info9 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 8).ArticleName, listaconferencias.get(value9).type, articleslist.get(counter + 8).year, listaconferencias.get(value9).title, listaconferencias.get(value9).Location, articleslist.get(value9).ISBN, articleslist.get(value9).DOI, articleslist.get(value9).Volume, articleslist.get(value9).Npages, articleslist.get(value9).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info9);
                }
                else{
                    int t=range3[random.nextInt(38)];
                    info info9 = new info(authorslist.get(counter).Name, authorslist.get(counter).Age, authorslist.get(counter).Nationality, authorslist.get(counter).email, articleslist.get(counter + 8).ArticleName, listaconferencias.get(value9).type, t, listaconferencias.get(value9).title, listaconferencias.get(value9).Location, articleslist.get(value9).ISBN, articleslist.get(value9).DOI, articleslist.get(value9).Volume, articleslist.get(value9).Npages, articleslist.get(value9).edition, Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)), Keywords.get(random.nextInt(87)));
                    information.add(info9);
                }

                counter = counter + 1;
            }
            else{
                counter = counter + 1;
            }
        }
        //This are the processes to write the csv file.
        FileWriter writer = new FileWriter("C:/Users/jmore/Desktop/sourcesOD/dataset-journal.csv");
        FileWriter writer2 = new FileWriter("C:/Users/jmore/Desktop/sourcesOD/dataset-conference.csv");
        String l = "AuthorName;" + "Age;" + "Nationality;" +"email;"+ "ArticleTitle;"+ "YearPublished;"+"ConferenceName;"+"Location;"+"ISBN;"+"DOI;"+"Volume;"+"Npages;"+"Edition;"+"keyword1;"+"keyword2;"+"keyword3;"+"keyword4;"+"\n";
        String l1 = "AuthorName;" + "Age;" + "Nationality;" +"email;"+ "ArticleTitle;"+ "YearPublished;"+"JournalName;"+"Location;"+"ISBN;"+"DOI;"+"Volume;"+"Npages;"+"Edition;"+"keyword1;"+"keyword2;"+"keyword3;"+"keyword4;"+"\n";


        writer.write(l);
        writer2.write(l1);
        //here comes the distinction with journals and conferences.
        for(info c : information) {
            if(c.CorJ=="Journal"){
            String f = c.AuthorName+";"+c.Age+";"+c.Nationality+";"+c.email+";"+c.Papertitle+";"+c.Year+";"+c.CorJTitle+";"+c.ConferenceLocation+";"+c.ISBN+";"+c.DOI+";"+c.Volume+";"+c.Npages+";"+c.edition+";"+c.keyword1+";"+c.keyword2+";"+c.keyword3+";"+c.keyword4+";"+"\n";
            writer.write(f);
            }
            else{
                String f = c.AuthorName+";"+c.Age+";"+c.Nationality+";"+c.email+";"+c.Papertitle+";"+c.Year+";"+c.CorJTitle+";"+c.ConferenceLocation+";"+c.ISBN+";"+c.DOI+";"+c.Volume+";"+c.Npages+";"+c.edition+";"+c.keyword1+";"+c.keyword2+";"+c.keyword3+";"+c.keyword4+";"+"\n";
                writer2.write(f);
            }
        }
        writer.close();
    }
}
