package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.IntStream;
//class that gets the information from articles.csv gets the information needed and fills the other with random values.
public class Article {

    String ArticleName;
    String ISBN;
    Integer year;
    int Npages;
    int Volume;
    int edition;
    String DOI;

//empty constructor,
    Article(){

        ArticleName="";
        ISBN="";
        DOI="";
        Npages=0;
        Volume=0;
        year=0;
        edition=0;

    }
//constructor with values.
    Article(String a,Integer y,String i,String d,int v,int n,int e){

        ArticleName=a;
        ISBN=i;
        DOI=d;
        year=y;
        Npages=n;
        Volume=v;
        edition=e;

    }
/*this function gets the info from articles.csv and fills the info about the articles, the information that we don't have
    in the csv file is generated randomly*/
    ArrayList<Article> getAllArticles() throws IOException {

        ArrayList<Article> Articleslist = new ArrayList<Article>();
        String row1;
        File csvFile = new File("C:/Users/jmore/Desktop/sourcesOD/authors.csv");
        if (csvFile.isFile()) {

            BufferedReader csvReader = new BufferedReader(new FileReader("C:/Users/jmore/Desktop/sourcesOD/articles.csv"));
            int no=0;
            while (no<60000) {
                row1 = csvReader.readLine();
                String[] data = row1.split(";");
                String year= data[7];
                String title= data[3];
                year = year.replaceAll("^\"|\"$", "");
                year = year.replaceAll("^\"|\"$", "");
                if(year.length()!=4 || year.contains("-")){

                }
                else {
                    title = title.replaceAll("^\"|\"$", "");
                    year.replace("\"", "");
                    Random random = new Random();
                    int npaginas,vol,edi;
                    int[] range1 = IntStream.rangeClosed(20, 200).toArray();
                    int[] range2 = IntStream.rangeClosed(1, 100).toArray();
                    int[] range3 = IntStream.rangeClosed(1, 30).toArray();
                    int[] range4 = IntStream.rangeClosed(100, 999).toArray();
                    int range5[]= IntStream.rangeClosed(100000, 999999).toArray();
                    npaginas=range1[random.nextInt(180)];
                    vol=range2[random.nextInt(90)];;
                    edi=range3[random.nextInt(6)];
                    String is= (range4[random.nextInt(800)])+"-"+random.nextInt(9)+"-"+random.nextInt(20)+"-"+(range5[random.nextInt(800)])+"-"+random.nextInt(9);
                    String Doi= random.nextInt(10)+"."+random.nextInt(9999)+"/"+(random.nextInt(26) + 'a')+(random.nextInt(26) + 'a')+(random.nextInt(26) + 'a')+(random.nextInt(26) + 'a')+random.nextInt(9999);
                    Article aux = new Article(title, Integer.parseInt(year),is,Doi,npaginas,vol,edi);
                    Articleslist.add(aux);
                }
                no++;
            }
            csvReader.close();

        }

        return Articleslist;

    }

}
