package com.company;

public class keywords {

    String keyword1,keyword2,keyword3,keyword4;


    public keywords(){



    }


    public keywords(String k1,String k2, String k3, String k4){

        keyword1=k1;
        keyword2=k2;
        keyword3=k3;
        keyword4=k4;


    }

}
