package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

public class Main {

    /*
    This program what it does is establish keywords for the conference to be a dataset more natural, and to try to get more instances from the querys
     */
    public static void main(String[] args) throws IOException {
        ArrayList<keywords> lista = new ArrayList<keywords>();
        //sets of keywords
        keywords k1 = new keywords("Machine Learning", "Deep learning", "NPL", "Reinforcement Learning");
        keywords k2 = new keywords("Service and cloud computing", "pervasive computing and collaboration", "Energy lab", "Scalable internet services");
        keywords k3 = new keywords("Computational Video", "Image-based Rendering and Animation", "3D Modelling of Humans", "3D Scene Analysis");
        keywords k4 = new keywords("type theory", "automated theorem proving", "language semantics", "computer security");
        keywords k5 = new keywords("computational complexity", "data structures", "parallel and distributed computation", "probabilistic computation");
        keywords k6 = new keywords("sequence alignment", "gene finding", "genome assembly", "drug design");
        //sets of conference in a map with their corresponding keywords
        Map<String, keywords> Mapa = new LinkedHashMap<>();
        Mapa.put("Science", k6);
        Mapa.put("Nucleic Acids Research", k6);
        Mapa.put("AAAI Conference on Artificial Intelligence", k1);
        Mapa.put("Annual Conference on Neural Information Processing Systems", k1);
        Mapa.put("IEEE Transactions on Cybernetics", k2);
        Mapa.put("International Conference on Machine Learning", k1);
        Mapa.put("IEEE Conference on Computer Vision and Pattern Recognition", k3);
        Mapa.put("International Conference on Computer Vision", k3);
        Mapa.put("Conference on Empirical Methods in Natural Language Processing", k4);
        Mapa.put("IEEE Transactions on Neural Networks and Learning Systems", k2);
        Mapa.put("Information Sciences", k6);
        Mapa.put("IEEE Transactions on Information Theory", k5);
        Mapa.put("IEEE Transactions on Image Processing", k3);
        Mapa.put("IEEE Transactions on Wireless Communications", k2);
        Mapa.put("European Conference on Computer Vision", k3);
        Mapa.put("IEEE Journal of Selected Areas in Communications", k2);
        Mapa.put("IEEE Transactions on Pattern Analysis and Machine Intelligence", k5);
        Mapa.put("NeuroImage", k6);
        Mapa.put("Annual Meeting of the Association for Computational Linguistics", k5);
        Mapa.put("Transactions on Geoscience and Remote Sensing", k6);
        String row1;
        File csvFile = new File("C:/Users/jmore/Desktop/sourcesOD/dataset-conference3.csv");
        Random random = new Random();
        int number = 0;
        FileWriter writer = new FileWriter("C:/Users/jmore/Desktop/sourcesOD/dataset-conference4.csv");
        if (csvFile.isFile()) {

            BufferedReader csvReader = new BufferedReader(new FileReader("C:/Users/jmore/Desktop/sourcesOD/dataset-conference3.csv"));
            while ((row1 = csvReader.readLine()) != null) {
                String[] data = row1.split(",");
                if(number==0){

                   String x= data[0]+";"+data[1]+";"+data[2]+";"+data[3]+";"+data[4]+";"+data[5]+";"+data[6]+";"+data[7]+";"+data[8]+";"+data[9]+";"+data[10]+";"+data[11]+";"+data[12]+";"+data[13]+";"+data[14]+";"+data[15]+";"+data[16]+";"+"\n";
                    writer.write(x);
                    number=number+1;
                }
                else{
                    keywords aux = Mapa.get(data[6]);
                    data[13]=aux.keyword1;
                    data[14]=aux.keyword2;
                    data[15]=aux.keyword3;
                    data[16]=aux.keyword4;
                    String k=data[0]+";"+data[1]+";"+data[2]+";"+data[3]+";"+data[4]+";"+data[5]+";"+data[6]+";"+data[7]+";"+data[8]+";"+data[9]+";"+data[10]+";"+data[11]+";"+data[12]+";"+data[13]+";"+data[14]+";"+data[15]+";"+data[16]+";"+"\n";
                    writer.write(k);
                    number=number+1;
                }


            }


        }
    }
}
